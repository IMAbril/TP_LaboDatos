﻿LÉEME:

Aquí encontrarás la información correspondiente para poder comprender los contenidos de 'TP02-thebeatles.zip'
En esta carpeta se encuentran dos archivos principales y una carpeta :
  * Un informe en formato PDF que detalla el trabajo realizado y las conclusiones obtenidas : TP-02-SignMNIST.pdf
  * Un archivo .py que contiene el códgio principal : sign_thebeatles.py
  * Una carpeta llamada Modulos, donde se encuentran los modulos importados en el archivo original.
     * Exploracion.py : Donde se encuentra el código correspondiente al análisis exploratorio realizado
     * KNN.py : En donde se encuentra el código correspondiente a la sección Clasificación binaria de el informe
     * ArbolesDecision.py : Aquí se encuentra el código correspondiente a la sección multiclase de el informe

_______________________________________________________________________________________________________________________________________________________________________________________________
Versiones requeridas para la ejecución de archivos:
  *Name: pandas  Version: 1.5.3
  *Name: seaborn Version: 0.13.2
  *Name: numpy Version: 1.26.2
  *Name: matplotlib Version: 3.8.0
  *Name: seaborn Version: 0.13.2
  *Name: inline-sql Version: 0.1.1
  *Name: scikit-learn Version: 1.2.2



